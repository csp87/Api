﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Api_Rest.Models
{
	public class GetMovies
	{

		public string id { get; set; }
		public string idUser { get; set; }

	}
}