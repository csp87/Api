﻿
namespace Api_Rest.Models
{
    public class Result
    {
        public bool Estatus { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }
    }
}